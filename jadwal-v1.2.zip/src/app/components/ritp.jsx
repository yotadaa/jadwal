import React, { useState } from 'react';


// import Timeit from "react-timeit";
// import "react-timeit/dist/index.css";

export default function MyApp() {

    return (
        <div className="p-2">
            <div
                className={`p-2 bg-emerald-300 rounded-xl`}
            >
                {/* <Timeit /> */}
            </div>
        </div>
    );
}