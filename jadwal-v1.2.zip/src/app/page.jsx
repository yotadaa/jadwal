// 'Page.js' on the client side
'use client'
import { useEffect, useContext, useState } from 'react';
import Master from './components/master';
import AppContext from './api/context/AppContext';
import JadwalBar from './components/jadwalBar';
import ProcessingAnimation from './components/processing';
import { decodeToken, getValue, getWaktu } from './api/context/functionality';
// import JadwalForm from './lihatjadwal/jadwal-form'
// import JadwalBar from './components/jadwalBar';

// import MyApp from './components/ritp';
import { useRouter } from 'next/navigation';
import Head from 'next/head';
import Menu from './components/left-bar';
export default function Page() {

  const isLogin = getValue('login') || false;
  const user = decodeToken();
  const router = useRouter();

  const context = useContext(AppContext);
  const [showProcessing, setShowProcessing] = useState(false);
  const [currentItem, setCurrentItem] = useState({});
  const [initialShow, setInitialShow] = useState(false);
  const [countForCurrentDay, setCountForCurrentDay] = useState(0);

  const getJadwal = async () => {
    try {
      setShowProcessing(true);
      const res = await fetch("../api/mongos/jadwals", {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        body: JSON.stringify({
          email: context.user.email,
          todo: "get",
        }),
      });

      const data = await res.json();
      if (data.success) {
        context.setJadwal(data.data);
        console.log(data.success);
      } else {
        console.error("Error fetching jadwal:", data.error);
      }
    } catch (err) {
      console.error("Error fetching jadwal:", err);
    } finally {
      setShowProcessing(false); // Only hide the processing animation once the try-catch block is complete
    }
  };


  useEffect(() => {
    getJadwal();
  }, [])

  const cancelAllDialog = (ev) => {
    ev.preventDefault();
    ev.stopPropagation();

    const isClickInsideDialog = ev.target.closest('.dialog-item'); // Replace 'your-dialog-class' with the actual class of your dialog

    if (!isClickInsideDialog) {
      setCurrentItem({});
    }
  }

  const daftarHari = [
    "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"
  ]


  useEffect(() => {
    context.setLeftBar(<Menu />)
    context.setRightBar(<JadwalBar />)

    context.setCurrentMenu(0);

    document.addEventListener("click", cancelAllDialog);

    return () => document.removeEventListener("click", cancelAllDialog);

  }, []);

  useEffect(() => {
    console.log(currentItem);
    console.log(Object.keys(currentItem).length);
  }, [currentItem])

  useEffect(() => {
    setCountForCurrentDay(context.jadwal ? context.jadwal.filter((item) => item.hari === context.currentDay).length : 0)
    console.log(countForCurrentDay);
  }, [context.jadwal, context.currentDay])

  if (isLogin && user) return (
    <>
      <Head>
        <title>Jadwalku</title>
      </Head>
      <div
      >
        <div>
          <div className='flex flex-col items-center justify-center p-5 pl-3 pt-0 pb-0 ml-2'>
            <div className='p-3 rounded-xl font-extrabold flex justify-start items-center w-full bg-white m-5 mb-1 shadow-xl'>
              Kamu {countForCurrentDay > 0 ? ` punya ${countForCurrentDay} ` : "tidak punya "} jadwal pada <span className='text-teal-600'> &nbsp; {" " + daftarHari[context.currentDay]}</span>
            </div>
          </div >
          <div className='flex flex-col items-center justify-center p-5'>
            {context.jadwal && context.jadwal.map((item, index) => {
              if (item.hari === context.currentDay) return (
                <div className={`dialog-item flex items-center justify-start bg-emerald-100 w-full rounded-lg shadow-xl mb-2 hover:opacity-80 cursor-pointer select-none`}
                  onClick={(ev) => {
                    // ev.preventDefault();
                    ev.stopPropagation();
                    setCurrentItem(item);
                  }}
                >
                  <div className="p-2 shadow-md bg-emerald-300 rounded-l-lg">
                    {getWaktu(item.mulai)[0]} : {getWaktu(item.mulai)[1]}
                  </div>
                  <div className="p-2 bg-emerald-200 shadow-md">
                    {getWaktu(item.selesai)[0]} : {getWaktu(item.selesai)[1]}
                  </div>
                  <div className="p-2 font-bold">
                    {item.judul}
                  </div>
                </div>
              )
            })}
          </div>
          <div className={`${Object.keys(currentItem).length > 0 ? "flex" : "hidden"}`}>
            {currentItem.judul}
          </div>
          <div className={`${showProcessing ? "block" : 'hidden'}`}>
            <ProcessingAnimation />
          </div>
        </div>
      </div>
    </>
  );
  else {
    useEffect(() => router.push("/login"), [])
    return <></>
  }
}
