'use client'

import { useEffect, useState, useContext } from 'react';
import { useRouter } from 'next/navigation';
import AppContext from '../api/context/AppContext';
import { getValue, storeValue } from '../api/context/functionality';
import JadwalBar from './jadwalBar';
import TugasBar from './tugasBar';
import FriendBar from './friendBar';
import { Link } from 'next/link';

export default function Menu() {
    const context = useContext(AppContext);
    const router = useRouter();

    return (
        <div className='p-2'>
            <div className='font-bold mt-2 p-2 rounded-lg text-sm flex items-center justify-start py-3 '>
                MENU
            </div>
            {context.menuItem.map((item, index) => {
                return (
                    <div key={index} className={`hover:bg-emerald-300 hover:font-bold ${context.currentMenu === index ? "bg-emerald-300" : "bg-white"} mt-2 p-2 rounded-lg text-xs flex items-center ${context.windowWidth > 700 ? "justify-start" : "justify-center"} py-3 gap-3 shadow-lg cursor-pointer select-none hover:opacity-80`}
                        onClick={() => {
                            context.setCurrentMenu(index);
                            storeValue("current-menu", index);
                            router.push(item.target);
                            context.setCurrentLink(item.target);
                            context.setPaddingTugas(0);
                            if (index === 3) {
                                context.getTugas(context.friendEmail);
                                context.setRightBar(<TugasBar />)
                            }
                            else if (index === 4) {
                                context.getTugas(context.user.email);
                                context.setRightBar(<FriendBar />)
                            }
                            else context.setRightBar(<JadwalBar />)
                        }}>
                        <div><img src={item.href} width={25} className='shadow-md rounded-full' /></div>
                        <div
                            className={` font-bold`}
                        >
                            {item.name}
                        </div>
                    </div>
                )
            })}
        </div>
    )
}