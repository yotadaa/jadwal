import FixedContainer from '../components/fixedContainer';
import { useState, useContext } from "react";
import { DownOutlined, CaretRightFilled } from '@ant-design/icons';
import { Button, Dropdown, message, Space, Tooltip, TimePicker } from 'antd';
import moment from 'moment';
import AppContext from '../api/context/AppContext';
import ProcessingAnimation from '../components/processing';
import Notification from '../components/notification';


export default function JadwalForm(props) {
    const context = useContext(AppContext)
    const { showJadwalForm, setShowJadwalForm } = props.component;
    const inputStyle = "w-full p-2 px-4 placeholder:text-gray-600 focus:outline-gray-500 focus:bg-gray-50 bg-gray-100 rounded-sm border border-gray-500";
    const inputContainer = "mt-3 flex flex-col";
    const [judul, setJudul] = useState("");
    const [lokasi, setLokasi] = useState("");
    const [deskripsi, setDeskripsi] = useState("");
    const [choosenDay, setChoosenDay] = useState(0);
    const [startTime, setStartTime] = useState(moment('9:00', 'HH:mm'));
    const [endTime, setEndTime] = useState(moment('17:00', 'HH:mm'));
    const [choosenRepeat, setChoosenRepeat] = useState(0);

    const handleRepeatClick = (e) => {
        setChoosenRepeat(e.key - 1);
    }

    const handleMenuClick = (e) => {
        setChoosenDay(e.key - 1);
    };
    const daftarRepeat = [
        "None", "Harian", "Mingguan"
    ]
    const daftarHari = [
        "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"
    ]
    const items = [
        {
            label: 'Senin',
            key: 1,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Selasa',
            key: 2,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Rabu',
            key: 3,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Kamis',
            key: 4,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Jumat',
            key: 5,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Sabtu',
            key: 6,
            icon: <CaretRightFilled />,
        },
        {
            label: 'Minggu',
            key: 7,
            icon: <CaretRightFilled />,
        },
    ];

    const menuProps = {
        items,
        onClick: handleMenuClick,
    };


    return (
        <FixedContainer
            style={{
                backgroundColor: 'rgba(0,0,0,0.2)',
                display: showJadwalForm ? "flex" : "none",
            }}
        >
            <div
                className="bg-white rounded-xl relative shadow-2xl mb-20"
                style={{
                    width: 490,
                    // height: 300,
                }}
            >
                <div className=" rounded-t-xl w-full h-9 flex items-center justify-between pr-1 pl-3">
                    <div className="font-bold text-lg flex items-center gap-2" >
                        <img
                            src='assets/calendar-month.png'
                            width={20}
                            onClick={() => {
                                setShowJadwalForm(false);
                            }}
                            className="hover:opacity-80 cursor-pointer"
                        />
                        <div>Buat Jadwal</div>
                    </div>
                    <img
                        src='assets/close.png'
                        width={30}
                        onClick={() => {
                            setShowJadwalForm(false);
                        }}
                        className="hover:opacity-80 cursor-pointer"
                    />
                </div>
                <div className='p-5'>
                    <div className={inputContainer}>
                        <label for="judul" className={`ml-3 ${judul.length > 0 ? "block" : "hidden"}`}>
                            Judul Tugas
                        </label>
                        <input
                            id="judul"
                            type="text"
                            placeholder="Judul tugas"
                            className={inputStyle}
                            value={judul}
                            onChange={(ev) => {
                                setJudul(ev.target.value);
                            }}
                        />
                    </div>
                    <div className='flex gap-1'>
                        <div className={`flex flex-row gap-4 mt-3 ml-5 items-center`}>
                            <div>Hari</div>
                            <div>
                                <Dropdown menu={menuProps}>
                                    <Button>
                                        <Space>
                                            {daftarHari[choosenDay]}
                                            <DownOutlined />
                                        </Space>
                                    </Button>
                                </Dropdown>
                            </div>
                        </div>
                        <div className={`flex flex-row gap-4 mt-3 ml-5 items-center`}>
                            <div>Waktu</div>
                            <div>
                                <TimePicker.RangePicker
                                    format="HH:mm"
                                    onChange={(time, timeString) => {
                                        setStartTime(moment(timeString[0]));
                                        setEndTime(moment(timeString[1]));
                                        console.log(startTime, endTime);
                                    }}
                                    defaultValue={[startTime, endTime]}
                                // value={[startTime, endTime]}
                                />
                            </div>
                        </div>
                    </div>
                    {/* <div className={`flex flex-row gap-4 mt-3 ml-5 items-center`}>
                        <div>Repeat</div>
                        <div>
                            <div>
                                <Dropdown menu={repeatProps}>
                                    <Button>
                                        <Space>
                                            {daftarHari[choosenDay]}
                                            <DownOutlined />
                                        </Space>
                                    </Button>
                                </Dropdown>
                            </div>
                        </div>
                    </div> */}
                    <div className={inputContainer}>
                        <label for="judul" className={`ml-3 ${lokasi.length > 0 ? "block" : "hidden"}`}>
                            Lokasi
                        </label>
                        <input
                            id="judul"
                            type="text"
                            placeholder="Lokasi"
                            className={inputStyle}
                            value={lokasi}
                            onChange={(ev) => {
                                setLokasi(ev.target.value);
                            }}
                        />
                    </div>
                    <div className={inputContainer}>
                        <label for="judul" className={`ml-3 ${deskripsi.length > 0 ? "block" : "hidden"}`}>
                            Deskripsi Tugas
                        </label>
                        <textarea
                            placeholder="Deskripsi tugas"
                            className={inputStyle + "rounded-2xl max-h-32 border border-gray-500"}
                            value={deskripsi}
                            onChange={(ev) => {
                                setDeskripsi(ev.target.value);
                            }}
                        />
                    </div>
                    <div className="w-full mt-5 flex items-center justify-end px-1">
                        <div type="submit" className="text-base cursor-pointer px-8 rounded-full font-bold text-white py-2 bg-blue-400 hover:opacity-80" value={`Buat!`}
                            onClick={(ev) => {
                                ev.preventDefault();
                                ev.stopPropagation();
                                if (judul.length === 0 || deskripsi.length === 0 || lokasi.length === 0) {
                                    context.insertNotif("Tolong isi semua field", true);
                                } else {
                                    submitForm();
                                }
                            }}
                        >
                            {props.task ? "UBAH!" : "BUAT!"}
                        </div >
                    </div>
                </div>
            </div>
            <div className={`${context.showProcessing ? "block" : 'hidden'}`}>
                <ProcessingAnimation />
            </div>
            <div className={`${context.notif.length > 0 ? "block" : "hidden"}`}>
                {context.notif.map((item, index) => {
                    return (
                        <Notification message={item.message} danger={item.danger} key={index} />
                    )
                })}
            </div>
        </FixedContainer>
    )
}