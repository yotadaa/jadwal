import { ReactNode, ReactElement, useContext, useState, useEffect } from 'react';
import Menu from './left-bar';
import Container from './container';
import { color } from './environment';
import AppContext from '../api/context/AppContext';
import Head from 'next/head';

interface PropsLayout {
    children: ReactNode;
}

export default function Master({ children }: PropsLayout) {
    const context = useContext(AppContext);
    const { light, dark } = color;
    const [windowWidth, setWindowWidth] = useState(0);
    const [windowHeight, setWindowHeight] = useState(0);
    const [currentColor, setCurrentColor] = useState(light);
    const [initialShow, setInitialShow] = useState(false);
    const [currentPath, setCurrentPath] = useState(window.location.pathname);

    useEffect(() => {
        const trackWindowSize = () => {
            setWindowWidth(window.innerWidth);
            setWindowHeight(window.innerHeight);
        };

        trackWindowSize();

        window.addEventListener("resize", trackWindowSize);
        return () => window.removeEventListener("resize", trackWindowSize);
    }, []);
    useEffect(() => {
        context.setWindowWidth(windowWidth);
    }, [windowWidth])

    useEffect(() => {
        console.log(window.location.pathname)
        if (context.jadwal && context.user) {
            setInitialShow(true);
        } else setInitialShow(false);
    }, [context.user, context.tugas, context.jadwal])

    return (
        <Container >
            <Head>
                <title>Jadwalku</title>
                <link
                    rel="icon"
                    href="assets/schedule.ico<generated>"
                    type="image/<generated>"
                    sizes="<generated>"
                />
                <meta name="description" content="A Simple schedule and task management app" />
            </Head>
            <div className={`flex justify-center ${initialShow ? "opacity-100" : "opacity-100"}`}
            >
                <div
                    className={` overflow-y-auto custom-scrollbar`}
                    style={{
                        width: 200,//windowWidth > 700 ? 200 : 70,
                        height: windowHeight > 675 ? windowHeight : 675,
                    }}>
                    {context.leftBar}
                </div>
                <div className={` overflow-y-auto custom-scrollbar`}
                    style={{
                        width: 500,
                        height: windowHeight > 675 ? windowHeight : 675,
                        paddingBottom: context.paddingTugas,
                        // marginBottom: context
                    }}
                >
                    {children}
                </div>
                <div
                    className={` overflow-y-auto custom-scrollbar`}
                    style={{
                        width: 200,//windowWidth > 700 ? 200 : 70,
                        height: windowHeight > 675 ? windowHeight : 675,
                    }}>
                    {(currentPath === "/login" || currentPath === "/daftar") ? <div></div> : context.rightBar}
                </div>
            </div>
        </Container>
    );
}