import { NextResponse } from "next/server";
import { connectDB } from '../connectDB';
import Jadwal from '../../../models/jadwal.model';


export async function POST(req) {
    const date = new Date();
    console.log(`${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`);
    const expires = '1y';
    try {
        await connectDB();
        const requestBody = await req.json();
        const { todo } = requestBody;

        if (todo === "get") {
            const { email } = requestBody;
            const jadwal = await Jadwal.find({
                email: email
            });
            return NextResponse.json({ success: true, data: jadwal });
        }
        return NextResponse.json({ success: false, err: 'Terjadi error' });
    } catch (err) {
        console.log("unexpected error " + err);
        return NextResponse.json({ success: false, err: err });
    }
}