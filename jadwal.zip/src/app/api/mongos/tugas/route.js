import { NextResponse } from "next/server";
import { connectDB } from '../connectDB';
import Tugas from '../../../models/tugas.model';


export async function POST(req) {
    const date = new Date();
    console.log(`${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`);
    try {
        await connectDB();
        const requestBody = await req.json();
        const { todo } = requestBody;

        if (todo === "get") {
            const { email } = requestBody;
            const tugas = await Tugas.find({
                email: email
            });
            console.log(tugas)
            return NextResponse.json({ success: true, data: tugas });
        }
        return NextResponse.json({ success: false, err: 'Terjadi error' });
    } catch (err) {
        console.log("unexpected error " + err);
        return NextResponse.json({ success: false, err: err });
    }
}