"use client"
import { ReactNode, useState, useEffect, useContext } from "react";
import { color } from './environment';
import AppContext from '../api/context/AppContext';


interface PropsLayout {
    children: ReactNode;
}

export default function Container({ children }: PropsLayout) {

    const context = useContext(AppContext);
    const { light, dark } = color;
    const [currentColor, setCurrentColor] = useState(light);


    const [windowWidth, setWindowWidth] = useState();
    const [windowHeight, setWindowHeight] = useState();

    useEffect(() => {
        const trackWindowSize = () => {
            setWindowWidth(window.innerWidth);
            setWindowHeight(window.innerHeight);
        };

        trackWindowSize();

        window.addEventListener("resize", trackWindowSize);
        return () => window.removeEventListener("resize", trackWindowSize);
    }, []);

    useEffect(() => {
        setCurrentColor(!context.theme ? light : dark);
    }, [context.theme])


    return (
        <>
            <div
                className={`${currentColor['latar']}`}
                style={{
                    width: windowWidth > 900 ? windowWidth : 900,
                    height: windowHeight > 675 ? windowHeight : 675,
                }}
            >
                {children}
            </div>
        </>
    );
}
