'use client'

import { useEffect, useState, useContext } from 'react';
import AppContext from '../api/context/AppContext';

export default function Menu() {
    const context = useContext(AppContext);

    return (
        <div className='p-2'>
            <div className='font-semibold bg-emerald-300 mt-2 p-2 rounded-lg text-xs flex items-center justify-start py-3 shadow-md'>
                Daftar Teman
            </div>
            {context.friendList.map((item, index) => {
                return (
                    <div key={index} className='select-none cursor-pointer bg-white mt-2 p-2 rounded-lg text-xs flex items-center justify-start py-3 shadow-md'>
                        {item.name}
                    </div>
                )
            })}
        </div>
    )
}