import { useContext, useEffect, useState } from "react"
import AppContext from "../api/context/AppContext";
import { storeValue } from "../api/context/functionality";


export default function JadwalBar() {

    const context = useContext(AppContext);

    const daftarHari = [
        "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"
    ]

    return (
        <div className='p-2'>
            <div className='font-semibold bg-white shadow-xl mt-2 p-2 rounded-lg text-xs flex items-center justify-start py-3 px-3 gap-2'>
                <div>
                    {context.user && context.profilePicture.map((item, index) => {
                        if (context.user.profile === item.name) return (
                            <div>
                                <img src={item.href}
                                    width={60}
                                    className='rounded-full hover:opacity-80 shadow-md select-none cursor-pointer'
                                />
                            </div>
                        )
                    })}
                </div>
                <div>
                    <div className='text-base font-semibold'>{context.user.firstName || ""}</div>
                </div>
            </div>
            {daftarHari.map((item, index) => {
                return (
                    <div
                        key={index}
                        className={`select-none cursor-pointer ${context.currentDay === index ? "bg-emerald-300" : "bg-white"} mt-2 p-2 rounded-lg text-xs flex items-center justify-start py-3 shadow-md px-3`}
                        onClick={() => {
                            context.setCurrentDay(index);
                            storeValue("current-day", index);
                        }}
                    >
                        {item}
                    </div>
                )
            })}
            <div className='bg-blue-300 hover:font-bold mt-2 p-2 rounded-lg text-xs flex items-center justify-start py-3 gap-3 shadow-lg cursor-pointer select-none hover:opacity-80'>
                <img
                    src='assets/plus.png'
                    width={20}
                />
                <div>Tambah Jadwal</div>
            </div>
        </div>
    )
}