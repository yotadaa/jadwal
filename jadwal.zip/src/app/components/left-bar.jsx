'use client'

import { useEffect, useState, useContext } from 'react';
import { useRouter } from 'next/navigation';
import AppContext from '../api/context/AppContext';
import { getValue, storeValue } from '../api/context/functionality';

export default function Menu() {
    const context = useContext(AppContext);
    const router = useRouter();
    const [currentMenu, setCurrentMenu] = useState(getValue("current-menu") || 0);

    return (
        <div className='p-2'>
            <div className='font-bold mt-2 p-2 rounded-lg text-sm flex items-center justify-start py-3 '>
                MENU
            </div>
            {context.menuItem.map((item, index) => {
                return (
                    <div key={index} className={`hover:bg-emerald-300 hover:font-bold ${currentMenu === index ? "bg-emerald-300" : "bg-white"} mt-2 p-2 rounded-lg text-xs flex items-center ${context.windowWidth > 700 ? "justify-start" : "justify-center"} py-3 gap-3 shadow-lg cursor-pointer select-none hover:opacity-80`}
                        onClick={() => {
                            storeValue("current-menu", index);
                            router.push(item.target);
                        }}>
                        <div><img src={item.href} width={25} className='shadow-md rounded-full' /></div>
                        <div
                            className={`${context.windowWidth > 700 ? "block" : "hidden"} font-bold`}
                        >
                            {item.name}
                        </div>
                    </div>
                )
            })}
        </div>
    )
}