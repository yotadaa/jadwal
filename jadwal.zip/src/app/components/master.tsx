import { ReactNode, ReactElement, useContext, useState, useEffect } from 'react';
import Menu from './left-bar';
import Container from './container';
import { color } from './environment';
import AppContext from '../api/context/AppContext';

interface PropsLayout {
    children: ReactNode;
    component: ReactElement;
}

export default function Master({ children, component }: PropsLayout) {
    const context = useContext(AppContext);
    const { light, dark } = color;
    const [windowWidth, setWindowWidth] = useState();
    const [windowHeight, setWindowHeight] = useState();
    const [currentColor, setCurrentColor] = useState(light);

    useEffect(() => {
        const trackWindowSize = () => {
            setWindowWidth(window.innerWidth);
            setWindowHeight(window.innerHeight);
        };

        trackWindowSize();

        window.addEventListener("resize", trackWindowSize);
        return () => window.removeEventListener("resize", trackWindowSize);
    }, []);
    useEffect(() => {
        context.setWindowWidth(windowWidth);
    }, [windowWidth])

    return (
        <Container>
            <div className="flex justify-center">
                <div
                    className={``}
                    style={{
                        width: windowWidth > 700 ? 200 : 70,
                        height: windowHeight,
                    }}>
                    <Menu />
                </div>
                <div className={`bg-white shadow-2xl`}
                    style={{
                        width: 500,
                    }}
                >
                    {children}
                </div>
                <div
                    className={``}
                    style={{
                        width: windowWidth > 700 ? 200 : 70,
                        height: windowHeight,
                    }}>
                    {component}
                </div>
            </div>
        </Container>
    );
}