"use client";

import MyApp from '../components/ritp';
import Master from '../components/master';
import FriendBar from '../components/friendBar';

export default function Home() {
    return (
        <Master component={<FriendBar />}>
            <MyApp />
        </Master>
    )
}