'use client'

import './globals.css';
import AppContext from './api/context/AppContext';
import { useEffect, useState } from 'react';
import Head from 'next/head';
import { decodeToken, getValue } from './api/context/functionality';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {

  let isLogin = getValue('login') || false;
  const users = decodeToken();

  const [user, setUser] = useState(users || {});
  const [windowWidth, setWindowWidth] = useState(0);

  const menuItem = [
    { name: "LIHAT JADWAL", href: "assets/calendar.png", target: "/" },
    { name: "JADWAL FAVORITE", href: "assets/star.png", target: "" },
    { name: "JADWAL KOSONG", href: "assets/schedule.png", target: "" },
    { name: "TUGAS", href: "assets/tasks.png", target: "/tugas" },
    { name: "AKUN", href: "assets/user (1).png", target: "/akun" },
  ];

  const friendList = [
    { name: "Reyhan" },
    { name: "Ghazuy" },
    { name: "Wildan" },
    { name: "RizkyAlfarizi" },
  ];

  const profilePicture = [
    { name: "male1", href: "assets/male1.png" },
    { name: "male2", href: "assets/male2.png" },
    { name: "male3", href: "assets/male3.png" },
    { name: "male4", href: "assets/male4.png" },
    { name: "female1", href: "assets/female1.png" },
    { name: "female2", href: "assets/female2.png" },
    { name: "female3", href: "assets/female3.png" },
    { name: "female4", href: "assets/female4.png" },
  ]

  const [theme, setTheme] = useState(getValue('current-theme'));

  const [currentDay, setCurrentDay] = useState(getValue("current-day") || 0);
  const [jadwal, setJadwal] = useState([]);
  const [tugas, setTugas] = useState([]);

  useEffect(() => {
    setCurrentDay(getValue("current-day") || 0);
    setTheme(getValue('current-theme'));
    isLogin = getValue("login") || false;
    setWindowWidth(window.innerWidth);
  }, [])

  const contextValue = {
    users, theme, setTheme, menuItem, friendList, profilePicture, user, setUser,
    currentDay, setCurrentDay, jadwal, setJadwal, windowWidth, setWindowWidth, tugas, setTugas
  }


  return (
    <html lang="en">
      <Head>
        <title>Jadwalku</title>
        <meta name="description" content="A Simple schedule and task management app" />
      </Head>
      <body>
        <AppContext.Provider value={contextValue}>
          {children}
        </AppContext.Provider>
      </body>
    </html>
  )
}
