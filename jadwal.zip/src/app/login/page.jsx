'use client'
import Login from './login';
import Container from '../components/container';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { decodeToken, getValue } from '../api/context/functionality';

export default function Home() {

    const isLogin = getValue('login') || false;
    const user = decodeToken();

    const router = useRouter();
    useEffect(() => {
        if (isLogin && user) {
            router.push("/")
        }
    }, [])


    return (
        <>
            <Login />
        </>
    );
}