// 'Page.js' on the client side
'use client'
import { useEffect, useContext, useState } from 'react';
import Master from '../components/master';
import AppContext from '../api/context/AppContext';
import TugasBar from '../components/tugasBar';
import ProcessingAnimation from '../components/processing';
import { epochToFormattedDatetime } from '../api/context/functionality';

export default function Page() {

    const context = useContext(AppContext);
    const [showProcessing, setShowProcessing] = useState(false);
    const [currentItem, setCurrentItem] = useState({});

    const getTugas = async () => {
        try {
            setShowProcessing(true);
            const res = await fetch("../api/mongos/tugas", {
                method: "POST",
                headers: {
                    "Content-type": "application/json",
                },
                body: JSON.stringify({
                    email: context.user.email,
                    todo: "get",
                }),
            });

            const data = await res.json();
            if (data.success) {
                context.setTugas(data.data);
                console.log(data.success);
            } else {
                console.error("Error fetching jadwal:", data.error);
            }
        } catch (err) {
            console.error("Error fetching jadwal:", err);
        } finally {
            setShowProcessing(false); // Only hide the processing animation once the try-catch block is complete
        }
    };

    const getClosest = (ev, arr) => {
        let state = false;
        for (var i = 0; i < arr.length; i++) {
            state = state || ev.target.closest(arr[i]);
        }

        return state;
    }

    const cancelAllDialog = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();

        // const isClickInsideDialog = ev.target.closest('.dialog-item') || ev.target.closest('.popup-dialog');

        const isClickInsideDialog = getClosest(ev, [
            ".dialog-item",
            "popup-dialog"
        ]);

        if (!isClickInsideDialog) {
            setCurrentItem({});
        }
    }

    useEffect(() => {

        document.addEventListener("click", cancelAllDialog);

        return () => document.removeEventListener("click", cancelAllDialog);

    }, []);


    useEffect(() => {
        getTugas();
    }, [])

    return (
        <Master component={<TugasBar />}
            style={{
                position: 'relative'
            }}
        >
            <div className='flex flex-col items-center justify-center p-5'>
                {context.tugas && context.tugas.map((item, index) => {
                    return (
                        <div
                            className={`dialog-item flex items-center justify-between bg-emerald-300 w-full rounded-lg shadow-xl mb-2 hover:opacity-80 cursor-pointer select-none`}
                            onClick={(ev) => {
                                // ev.preventDefault();
                                ev.stopPropagation();
                                setCurrentItem(item);
                            }}
                        >
                            <div className="p-2 font-bold">
                                {item.judul}
                            </div>
                            <div className="p-2 flex items-end justify-end text-right bg-red-200 rounded-r-lg">
                                <p>{epochToFormattedDatetime(item.deadline)}</p>
                            </div>
                        </div>
                    )
                })}
            </div>
            <div className={`${Object.keys(currentItem).length > 0 ? "flex" : "hidden"} absolute bottom-0`}
                style={{
                    width: 500,
                    height: 250
                }}
            >
                <div
                    className={`popup-dialog flex justify-center bg-emerald-300 shadow-xl rounded-t-3xl w-full`}
                >
                </div>
            </div>
            <div className={`${showProcessing ? "block" : 'hidden'}`}>
                <ProcessingAnimation />
            </div>
        </Master>
    );
}
